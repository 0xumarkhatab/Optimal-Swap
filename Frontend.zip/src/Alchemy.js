// Imports the Alchemy SDK
const { Alchemy, Network } = require("alchemy-sdk");

export const fetchUserTokens = async (ownerAddress,filterTokens,chainId) => {
// Configures the Alchemy SDK
const config = {
    apiKey: chainId==1? "vRDjYuMmSL38QBSJzpke7Ae7sSLotCGf":"HnSOUgh_2lwxYsubMtVu2mkuxlFeIE7q",
    network: chainId==1? Network.ETH_MAINNET:Network.MATIC_MAINNET // Replace with your network
  };
  // Creates an Alchemy object instance with the config to use for making requests
  const alchemy = new Alchemy(config);
    
  //The response returns the tokens the address owns and relevant metadata.
  
  let response = await alchemy.core.getTokensForOwner(ownerAddress)
  
  //Logging the response to the console
  console.log(response)
  return response.tokens
};
