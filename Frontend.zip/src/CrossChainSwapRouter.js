export const crossChainSwapRouterAddress="0xc4c0fd90e3434ec6869f7553bfe8b8a06b8ab1ac";
export const crossChainSwapRouterABI=[
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_1inchRouterAdderss_",
				"type": "address"
			}
		],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "srcToken",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "srcAmount",
				"type": "uint256"
			},
			{
				"internalType": "bytes",
				"name": "swapCallData",
				"type": "bytes"
			}
		],
		"name": "swap",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "destToken",
				"type": "address"
			}
		],
		"name": "withdraw",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	}
]
