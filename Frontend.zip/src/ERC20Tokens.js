export const popularDeployedERC20Tokens = {
  1: {
    USDT: {
      name: "Tether",
      symbol: "USDT",
      decimals: 6,
      contractAddress: "0xc2132D05D31c914a87C6611C10748AEb04B58e8F",
    },
    DAI: {
      name: "Dai",
      symbol: "DAI",
      decimals: 18,
      contractAddress: "0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063",
    },
    USDC: {
      name: "USD Coin",
      symbol: "USDC",
      decimals: 6,
      contractAddress: "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",
    },
    MATIC: {
      name: "Polygon",
      symbol: "MATIC",
      decimals: 18,
      contractAddress: "0x7d1afa7b718fb893db30a3ab0be05a414c245a51",
    },
  },
  137: {
    USDT: {
      name: "Tether",
      symbol: "USDT",
      decimals: 6,
      contractAddress: "0xc2132d05d31c914a87c6611c10748aeb04b58e8f",
    },
    DAI: {
      name: "Dai",
      symbol: "DAI",
      decimals: 18,
      contractAddress: "0x8f3cf7ad23cd3cadbd9735aff958023239c6a063",
    },
    USDC: {
      name: "USD Coin",
      symbol: "USDC",
      decimals: 6,
      contractAddress: "0x2791bca1f2de4661ed88a30c99a7a9449aa84174",
    },
    WBTC: {
      name: "Wrapped Bitcoin",
      symbol: "WBTC",
      decimals: 8,
      contractAddress: "0x1BFD67037B42Cf73acF2047067bd4F2C47D9BfD6",
    },

    UNI: {
      name: "Uniswap Uni Token",
      symbol: "UNI",
      decimals: 18,
      contractAddress: "0xb33EaAd8d922B1083446DC23f610c2567fB5180f",
    },
  },
  56: {
    USDT: {
      name: "Tether",
      symbol: "USDT",
      decimals: 18,
      contractAddress: "0x55d398326e2bDF424D133ac55F9029D25c796c3D",
    },
    WBTC: {
      name: "Wrapped Bitcoin",
      symbol: "WBTC",
      decimals: 18,
      contractAddress: "0x7130d2A12B9BCbFAe4f2634d864A1Ee1EE4197C3",
    },
    UNI: {
      name: "Uniswap",
      symbol: "UNI",
      decimals: 18,
      contractAddress: "0xBf5140A22C798dEc3ECd9c73478B42A70f9b665d",
    },
    DAI: {
      name: "Dai",
      symbol: "DAI",
      decimals: 18,
      contractAddress: "0x1AF3F329e8BE15b8670106743A72166A6c9F763D",
    },
    USDC: {
      name: "USD Coin",
      symbol: "USDC",
      decimals: 18,
      contractAddress: "0x8AC76a517c3144B0b433c5Db92403a0b252A016E",
    },
    LINK: {
      name: "Chainlink",
      symbol: "LINK",
      decimals: 18,
      contractAddress: "0xF8A0BF9cF86AAe5504e5b87928aC10668C9C6e22",
    },
    BNB: {
      name: "Binance Coin",
      symbol: "BNB",
      decimals: 18,
      contractAddress: "0xB8c7748f0eBE83b18fC3380fC7e396b192d80b3a",
    },
    CAKE: {
      name: "PancakeSwap",
      symbol: "CAKE",
      decimals: 18,
      contractAddress: "0x0E09FaBB73Bd3Ade0a17ECC321fD4DC752aBACE2",
    },
    BUSD: {
      name: "Binance USD",
      symbol: "BUSD",
      decimals: 18,
      contractAddress: "0xe9e7CEA3DedcA5984780Bfc0150eC2D5a35c77e3",
    },
    ALPHA: {
      name: "Alpha Finance",
      symbol: "ALPHA",
      decimals: 18,
      contractAddress: "0xa1faa113cbE5311e8Df283a6b0D7137d900d3d8C",
    },
  },
};
export const tokenIcons = {
  USDT: "https://cdn.coingecko.com/coins/images/325/large/tether.png",
  WBTC: "https://cdn.coingecko.com/coins/images/7597/large/wrapped-bitcoin.png",
  UNI: "https://cdn.coingecko.com/coins/images/9380/large/uniswap.png",
  DAI: "https://cdn.coingecko.com/coins/images/1831/large/dai.png",
  USDC: "https://cdn.coingecko.com/coins/images/6319/large/usd_coin.png",
  LINK: "https://cdn.coingecko.com/coins/images/877/large/chainlink.png",
  MATIC: "https://cdn.coingecko.com/coins/images/4713/large/matic-network.png",
  AAVE: "https://cdn.coingecko.com/coins/images/12559/large/aave.png",
  MKR: "https://cdn.coingecko.com/coins/images/1399/large/maker.png",
  LDO: "https://cdn.coingecko.com/coins/images/14831/large/lido-dao.png",
  BNB: "https://cdn.coingecko.com/coins/images/1839/large/binance-coin.png",
  CAKE: "https://cdn.coingecko.com/coins/images/14379/large/pancakeswap-token.png",
  BUSD: "https://cdn.coingecko.com/coins/images/12240/large/binance-usd.png",
  ALPHA: "https://cdn.coingecko.com/coins/images/13297/large/alpha.png",
};
