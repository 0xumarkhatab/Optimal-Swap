import {
  Box,
  Button,
  HStack,
  Heading,
  Input,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Select,
  Text,
  VStack,
} from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

import "./App.css";
import { useAccount, useConnect, useDisconnect, useSignMessage } from "wagmi";
import { InjectedConnector } from "wagmi/connectors/injected";
import Web3 from "web3";
import axios from "axios";
import { useEffect, useState } from "react";
import { ERC20Abi } from "./ERC20Abi";
import { ethers } from "ethers";
import {
  crossChainSwapRouterABI,
  crossChainSwapRouterAddress,
} from "./CrossChainSwapRouter";
import { popularDeployedERC20Tokens } from "./ERC20Tokens";
import { fetchUserTokens } from "./Alchemy";
import { BigNumber } from "ethers";

// const chainId = 137;// polygon
// const chainId = 1;// Ethereum
// const chainId = 56;// polygon
let supportedChainIds = [137, 1, 56];
const web3RpcUrl = "https://polygon-mainnet.infura.io"; // The URL for the Polygon node you want to connect to
const walletAddress = "0x927F750555A2e72E4670a45733CBA3d794516Fe8"; // Set your wallet address (replace '0x...xxx' with your actual wallet address)
const _privateKey =
  "00061993a7a116548044e16ee9cae2781d01cfa86262f5807b82bfdc5dcbb3b0cf8"; // Set the private key of your wallet (replace '0x...xxx' with your actual private key). NEVER SHARE THIS WITH ANYONE!
const privateKey = _privateKey.slice(3);

let backendApi = "http://localhost:8080";
const _1inchTokenAddress = "0x9c2C5fd7b07E95EE044DDeba0E97a665F142394f";
const _daiTokenAddress = "0x84000b263080BC37D1DD73A29D92794A6CF1564e";
const _wMaticTokenAddress = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270";

const _1inchRouterAddress = "0x1111111254eeb25477b68fb85ed929f73a960582";

const web3 = new Web3(web3RpcUrl);
const API_TOKEN = "Bearer MlhEps5HQRxJXRsZahy1AEUtC7PAjksY";

function App() {
  // State variables

  const [currenChainId, setCurrentChainId] = useState(null);
  const [destinationToken, setDestinationToken] = useState(null);
  const [srcToken, setSrcToken] = useState(null);
  const [userTokens, setUserTokens] = useState(null);
  const [srcAmount, setSrcAmount] = useState(0);

  console.log({ currenChainId, srcToken, destinationToken });
  const { address, isConnected } = useAccount();
  const { connect } = useConnect({
    connector: new InjectedConnector(),
  });
  const { disconnect } = useDisconnect();
  const { signMessage } = useSignMessage({
    message:
      "You are signing this message just to confirm that you want to use SwapFusion.",
    onSuccess: () => {
      window.location.href = "/home";
    },
  });

  //----------------------//

  async function authenticate() {
    await signMessage();
  }

  async function connectWallet() {
    try {
      let provider = window.ethereum;
      let accounts = await provider.request({
        method: "eth_requestAccounts",
      });
      console.log({ accounts, provider });
      // console.log();
      // console.log(provider.getNetwork());

      if (!supportedChainIds.includes(parseInt(provider.chainId))) {
        alert(
          "Please switch to Polygon , Ethereum or BSC Mainnet in MetaMask !"
        );
      }
      // getting signer
      setCurrentChainId(parseInt(provider.chainId));

      provider = new ethers.providers.Web3Provider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      const signer = provider.getSigner();
      // console.log(signer);

      return { signer, account: accounts[0] };
    } catch (e) {
      alert("Error in Connecting Wallet !!!");
      console.log(e);
      return null;
    }
  }

  // async function buildTxForSwap(swapParams) {
  //   const response = await axios.get(
  //     "https://api.1inch.dev/swap/v5.2/137/swap",
  //     {
  //       headers: {
  //         Authorization: API_TOKEN,
  //       },
  //       params: {
  //         ...swapParams,
  //       },
  //     }
  //   );

  //   // Fetch the swap transaction details from the API
  //   return response.data;
  // }

  async function swap() {
    try {
      let _sourceToken = userTokens.filter(
        (item) => item.symbol == srcToken
      )[0];
      let _targetToken =
        popularDeployedERC20Tokens[currenChainId][destinationToken];
      let rawAmount = BigNumber.from(parseInt(srcAmount*10000)+'') * (10 ** BigNumber.from(_sourceToken.decimals-6+'') );
      let swapAmount = rawAmount;
      // const swapAmount = parseInt(srcAmount * 10 ** _sourceToken.decimals);
      console.log({ _sourceToken, _targetToken, swapAmount, rawAmount });

      let { signer, account } = await connectWallet();
      if (!signer) return;
      console.log("signer is ", signer);
      const SourceTokenContract = new ethers.Contract(
        _sourceToken.contractAddress,
        ERC20Abi,
        signer
      );
      const crossChainRouterContract = new ethers.Contract(
        crossChainSwapRouterAddress,
        crossChainSwapRouterABI,
        signer
      );
        let tx;
        tx = await SourceTokenContract.approve(
        crossChainSwapRouterAddress,
        swapAmount
      );

      // let tx_ = await SourceTokenContract.approve(
      //   _1inchRouterAddress,
      //   swapAmount
      // );

      alert("Transaction Initiated 🐅");
      await tx.wait();
      // await tx_.wait();
      alert("Approved 🎉");

      let swapParams = {
        fromTokenAddress: _sourceToken.contractAddress, // The address of the token you want to swap from (1INCH)
        toTokenAddress: _targetToken.contractAddress, // The address of the token you want to swap to (DAI)
        amount: swapAmount, // The amount of the fromToken you want to swap (in wei)
        // decimals: _sourceToken.decimals,
        fromAddress: address, // Your wallet address from which the swap will be initiated
        slippage: 1, // The maximum acceptable slippage percentage for the swap (e.g., 1 for 1%)
        disableEstimate: false, // Whether to disable estimation of swap details (set to true to disable)
        allowPartialFill: false, // Whether to allow partial filling of the swap order (set to true to allow)
        from: address,
      };
      console.log("swap params ", swapParams);
      let response = await axios.get(backendApi + "/swap", {
        params: {
          swapParams,
          // privateKey,
        },
      });
      response = response.data;

      if (response.error) {
        alert("Unable to swap because : " + response.error.description);
        return;
      }

      console.log("transaction data is ", response.tx);
      //  function swap(address srcToken,address destToken,uint srcAmount,bytes memory swapCallData)public {
      alert("Intitiating Swap Transaction ...");
       tx = await crossChainRouterContract.swap(
        swapParams.fromTokenAddress,
        swapParams.amount,
        response.tx
      );
      alert("Waiting for Tx Confirmation ...");

      await tx.wait();
      alert("Tokens Swapped Successfully ✅");
    } catch (e) {
      alert("Error in Swap " + String(e));
    }
  }
  async function fetchUserTokensByChainId() {
    if (address && currenChainId) {
      let tokenContractAddresses = Object.keys(
        popularDeployedERC20Tokens[currenChainId]
      ).map((tokenName) => {
        return popularDeployedERC20Tokens[currenChainId][tokenName]
          .contractAddress;
      });
      console.log({ tokenContractAddresses });
      let _userTokens = await fetchUserTokens(
        address,
        tokenContractAddresses,
        currenChainId
      );

      let filteredTokens = [];
      for (let i = 0; i < _userTokens.length; i++) {
        const element = _userTokens[i];
        if (element.rawBalance > 0) {
          filteredTokens.push(element);
        }
      }

      console.log("user tokens ", filteredTokens);
      setUserTokens(filteredTokens);
    }
  }
  useEffect(() => {
    connectWallet();
  }, []);
  useEffect(() => {
    fetchUserTokensByChainId();
  }, [address, currenChainId]);
  useEffect(() => {
    if (srcToken) {
      setSrcAmount(
        userTokens.filter((item) => item.symbol == srcToken)[0].balance
      );
    }
  }, [srcToken]);

  return (
    <>
      <Box
        display={"flex"}
        justifyContent={"center"}
        alignItems={"center"}
        width={"100vw"}
        height={"100vh"}
        position="absolute"
        top="0"
        style={{
          minHeight: "100vh",
          backgroundSize: "cover",
          background: `url("./bg.jpg")`,
          backgroundSize: "cover",
          boxShadow: "inset 100px 0 0 2000px rgba(0, 0, 0, 0.3)",
        }}
      >
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          justifyContent={"space-between"}
          height={"70vh"}
          width={"30vw"}
          color="white"
          border={"1px solid grey"}
          borderRadius={"20px"}
          boxShadow="inset 0px 0 0 2000px rgba(0, 0, 0, 0.1)"
          padding={"10vh"}
        >
          <Box>
            <Heading fontSize="2em">Optimal Swap</Heading>
            <Text fontSize="1.5em">Swap at best prices</Text>
          </Box>
          <Box>
            {isConnected ? (
              <Box>
                <VStack align={"left"} spacing={5}>
                  <Text fontSize={"18px"}>Select Source Token</Text>
                  {userTokens == null ? (
                    <Text>Loading....</Text>
                  ) : userTokens.length == 0 ? (
                    <option key={"srcZero"}>No Tokens to trade</option>
                  ) : (
                    <Select
                      pb={"10px"}
                      bg={"black"}
                      color={"white"}
                      placeholder="Select"
                      onChange={(e) => {
                        setSrcToken(e.target.value);
                      }}
                    >
                      {userTokens.length > 0 &&
                        userTokens.map((token) => {
                          return (
                            <option
                              key={"src" + token.symbol}
                              style={{
                                background: "black",
                                color: "white",
                              }}
                              value={token.symbol}
                            >
                              {token.symbol}
                            </option>
                          );
                        })}
                    </Select>
                  )}
                </VStack>
                <VStack align={"left"} fontSize={"18px"} spacing={5}>
                  <Text>Select Destination Token</Text>
                  {currenChainId && (
                    <Select
                      pb={"10px"}
                      bg={"black"}
                      color={"white"}
                      placeholder="Select"
                      onChange={(e) => {
                        setDestinationToken(e.target.value);
                      }}
                    >
                      {/* <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option> */}
                      {currenChainId &&
                        Object.keys(
                          popularDeployedERC20Tokens[currenChainId]
                        ).map((tokenName) => {
                          return (
                            <option
                              key={"dest" + tokenName}
                              style={{
                                background: "black",
                                color: "white",
                              }}
                              value={tokenName}
                            >
                              {tokenName}
                            </option>
                          );
                        })}
                    </Select>
                  )}
                </VStack>
                {srcToken && (
                  <Input
                    mt="20px"
                    mb={"20px"}
                    variant="outline"
                    placeholder={srcToken + " Tokens to swap"}
                    value={srcAmount}
                    onChange={(e) => setSrcAmount(e.target.value)}
                  />
                )}
                <Button colorScheme="blue" onClick={() => swap()}>
                  Swap
                </Button>
              </Box>
            ) : (
              <Button colorScheme="blue" onClick={() => connect()}>
                Connect Wallet
              </Button>
            )}
          </Box>
        </Box>
      </Box>
    </>
  );
}

export default App;
