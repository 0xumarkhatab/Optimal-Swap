const Web3 = require('web3'); // Import the Web3 library for interacting with Ethereum
const fetch = require('node-fetch'); // Import the fetch library for making HTTP requests
const yesno = require('yesno'); // Import the yesno library for prompting user input

const chainId = 137; 
const web3RpcUrl = 'https://polygon-mainnet.infura.io'; // The URL for the Polygon node you want to connect to
const walletAddress = '0x927F750555A2e72E4670a45733CBA3d794516Fe8'; // Set your wallet address (replace '0x...xxx' with your actual wallet address)
const _privateKey = '00061993a7a116548044e16ee9cae2781d01cfa86262f5807b82bfdc5dcbb3b0cf8'; // Set the private key of your wallet (replace '0x...xxx' with your actual private key). NEVER SHARE THIS WITH ANYONE!
const privateKey=_privateKey.slice(3)
console.log({privateKey});
const _1inchTokenAddress="0x9c2C5fd7b07E95EE044DDeba0E97a665F142394f"
const _daiTokenAddress="0x84000b263080BC37D1DD73A29D92794A6CF1564e"
const swapAmount=0.01
const broadcastApiUrl = 'https://tx-gateway.1inch.io/v1.1/' + chainId + '/broadcast';
const apiBaseUrl = 'https://api.1inch.io/v5.0/' + chainId;
const web3 = new Web3.Web3(web3RpcUrl);
console.log(web3);
const swapParams = {
    fromTokenAddress: _1inchTokenAddress, // The address of the token you want to swap from (1INCH)
    toTokenAddress: _daiTokenAddress, // The address of the token you want to swap to (DAI)
    amount: web3.utils.toWei(swapAmount,'wei'), // The amount of the fromToken you want to swap (in wei)
    fromAddress: walletAddress, // Your wallet address from which the swap will be initiated
    slippage: 1, // The maximum acceptable slippage percentage for the swap (e.g., 1 for 1%)
    disableEstimate: false, // Whether to disable estimation of swap details (set to true to disable)
    allowPartialFill: false, // Whether to allow partial filling of the swap order (set to true to allow)
};
console.log(swapParams);

// Construct full API request URL
function apiRequestUrl(methodName, queryParams) {
    return apiBaseUrl + methodName + '?' + (new URLSearchParams(queryParams)).toString();
}

async function checkAllowance(tokenAddress, walletAddress) {
    console.log("checking allowance of ",walletAddress," for ",tokenAddress);
    let apiURL=apiRequestUrl('/approve/allowance', {tokenAddress, walletAddress})
    let res= await fetch(apiURL )
    console.log(res);

}

// Post raw transaction to the API and return transaction hash
async function broadCastRawTransaction(rawTransaction) {
    return fetch(broadcastApiUrl, {
        method: 'post',
        body: JSON.stringify({ rawTransaction }),
        headers: { 'Content-Type': 'application/json' }
    })
        .then(res => res.json())
        .then(res => {
            return res.transactionHash;
        });
}

// Sign and post a transaction, return its hash
async function signAndSendTransaction(transaction) {
    const { rawTransaction } = await web3.eth.accounts.signTransaction(transaction, privateKey);

    return await broadCastRawTransaction(rawTransaction);
}

// Prepare approval transaction, considering gas limit
async function buildTxForApproveTradeWithRouter(tokenAddress, amount) {
    const url = apiRequestUrl(
        '/approve/transaction',
        amount ? { tokenAddress, amount } : { tokenAddress }
    );

    const transaction = await fetch(url).then(res => res.json());

    const gasLimit = await web3.eth.estimateGas({
        ...transaction,
        from: walletAddress
    });

    return {
        ...transaction,
        gas: gasLimit
    };
}
// Prepare the transaction data for the swap by making an API request
async function buildTxForSwap(swapParams) {
    const url = apiRequestUrl('/swap', swapParams);

    // Fetch the swap transaction details from the API
    return fetch(url)
        .then(res => res.json())
        .then(res => res.tx);
}

async function main() {

    const allowance = await checkAllowance(swapParams.fromTokenAddress, walletAddress);
    console.log('Allowance: ', allowance);
    // const transactionForSign = await buildTxForApproveTradeWithRouter(swapParams.fromTokenAddress);
    // console.log('Transaction for approve: ', transactionForSign);
    // const ok = await yesno({
    //     question: 'Do you want to send a transaction to approve trade with 1inch router?'
    // });
    
    // if (!ok) {
    //     return false;
    // }
    
    // const approveTxHash = await signAndSendTransaction(transactionForSign);
    // console.log('Approve tx hash: ', approveTxHash);
    
    // // First, let's build the body of the transaction
    // const swapTransaction = await buildTxForSwap(swapParams);
    // console.log('Transaction for swap: ', swapTransaction);
    // // Prompt the user to confirm the transaction before signing and sending it
    //  ok = await yesno({
    //     question: 'Do you want to send a transaction to exchange with 1inch router?'
    // });
    
    // // Confirm that all parameters are specified correctly before signing the transaction
    // if (!ok) {
    //     return false;
    // }
    
    // // Sign and send the swap transaction, and retrieve the transaction hash
    // const swapTxHash = await signAndSendTransaction(swapTransaction);
    // console.log('Transaction Signed and Sent: ', swapTxHash);
        
}
main();
